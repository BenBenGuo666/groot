package com.xwtech.mall.newMall.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.coobird.thumbnailator.Thumbnails;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.xwtech.bmon.framework.constants.IResultCode;
import com.xwtech.bmon.framework.pojo.UserInfoBean;
import com.xwtech.mall.newMall.entity.prepair.HallINfoBean;
import com.xwtech.mall.newMall.entity.prepair.PrepairInfoBean;
import com.xwtech.mall.newMall.service.EcpService;
import com.xwtech.mall.newMall.service.OldPhoneRecoveryService;
import com.xwtech.mall.newMall.service.PrepairService;
import com.xwtech.mall.newMall.service.SendMessageService;
import com.xwtech.mall.newMall.util.GetUserUtil;
import com.xwtech.mall.newMall.util.LogicResult;
import com.xwtech.mall.newMall.util.ResultCode;
import com.xwtech.mall.newMall.util.SMSUtil;
import com.xwtech.mall.newMall.util.WEBApp;
import com.xwtech.xwecp.msg.InvocationContext;
import com.xwtech.xwecp.service.logic.client.LIInvocationContext;
import com.xwtech.xwecp.service.logic.client_impl.common.IQueryUserService;
import com.xwtech.xwecp.service.logic.pojo.QRY040129Result;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;

import javax.crypto.Cipher;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bouncycastle.jce.provider.BouncyCastleProvider;  

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * @author lishan
 * 维修页面
 */
@Controller
@RequestMapping(value = "prepair")
public class RepairController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Resource(name = "queryUserService")
	IQueryUserService queryUserService;
	
	@Resource(name = "sendMessageService")
	SendMessageService sendMessageService;
	
	@Resource
    OldPhoneRecoveryService oldPhoneRecoveryService;
	
	@Autowired
    private PrepairService prepairService;
	
	private static final String DEFAULT_PUBLIC_KEY=
	        "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQChDzcjw/rWgFwnxunbKp7/4e8w" + "\r" +
	                "/UmXx2jk6qEEn69t6N2R1i/LmcyDT1xr/T2AHGOiXNQ5V8W4iCaaeNawi7aJaRht" + "\r" +
	                "Vx1uOH/2U378fscEESEG8XDqll0GCfB1/TjKI2aitVSzXOtRs8kYgGU78f7VmDNg" + "\r" +
	                "XIlk3gdhnzh+uoEQywIDAQAB" + "\r";
    
    @RequestMapping("index.html")
    public ModelAndView index(HttpServletRequest request, HttpServletResponse response) {
    	logger.info("进入维修页面");
    	
    	return new ModelAndView("prepair");

    }
    @RequestMapping("prepairResult.html")
    public ModelAndView prepairId(HttpServletRequest request, HttpServletResponse response) {
    	logger.info("进入结果页面");
    	
    	return new ModelAndView("prepairResult").addObject("prepairId", request.getParameter("prepairId"));
    	
    }
    
    
    @ResponseBody
    @RequestMapping("getUserInfo.json")
    public LogicResult getUserInfo(HttpServletRequest request, HttpServletResponse response) {
        LogicResult result = LogicResult.newInstance(ResultCode.S_FAIL);
        UserInfoBean user = GetUserUtil.getUser(request, response);
       
        String city ="";
        if(null!=user){
        	 try {
				userInfoLogicImp(user.getMobile(), "14");
				QRY040129Result qry040129Result = queryUserService.queryUser(user.getMobile());
				city = qry040129Result.getCity();

				List<HallINfoBean> hallList = prepairService.queryHallList(city);
				result.setResult(hallList);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
       }else{
        	result.setResCode("100001");
        }
		return result;
        
    }
    @ResponseBody
    @RequestMapping("getHallInfo.json")
    public LogicResult getHallInfo(HttpServletRequest request, HttpServletResponse response) {
    	LogicResult result = LogicResult.newInstance(ResultCode.S_FAIL);
    	String hallNum = request.getParameter("hallNum");
    	HallINfoBean hall = prepairService.queryHallInfo(hallNum);
    	result.setResult(hall);
    	return result;
    	
    }
    @ResponseBody
    @RequestMapping("to51.html")
    public ModelAndView to51(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	LogicResult result = new LogicResult();
    	UserInfoBean user = GetUserUtil.getUser(request, response);
    	String jumpUrl = "http://m.51xiu.cc/mi/step_1?51xiuj-wx-menu=&type=2&channeKey=39984d00382341e3ae498502fa427869";
    	 if(oldPhoneRecoveryService.isAgreeLogin(user.getMobile(),"4")){
   		  response.sendRedirect(jumpUrl);
   	  }else{
   		ModelAndView view = new ModelAndView("tcb51Page");
		return view; 
   	  }
		return null;
    	
    	
    	
    }
    @ResponseBody
    @RequestMapping("toJK.html")
    public ModelAndView toJK(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	LogicResult result = new LogicResult();
    	UserInfoBean user = GetUserUtil.getUser(request, response);
     
      if(null!=user){
    	  byte[] encMobile = encrypt(getPublicKey(DEFAULT_PUBLIC_KEY),user.getMobile().getBytes());
    	  BASE64Encoder encoder = new BASE64Encoder();    	     	 
    	  String mobile = encoder.encode(encMobile);
    	  String redirect_url="https%3a%2f%2fm.jikexiu.com%3forderSource%3d800";
    	  mobile= java.net.URLEncoder.encode(mobile ,"utf-8" );
    	  String jumpUrl ="https://account.jikexiu.com/third/js10086?mobile="
    	  + mobile
    	  + "&redirect_url="
    	  + redirect_url; 
    	  if(oldPhoneRecoveryService.isAgreeLogin(user.getMobile(),"3")){
    		  response.sendRedirect(jumpUrl);
    	  }else{
    		  ModelAndView view = new ModelAndView("tcbJkPage");            
              view.addObject("jumpUrl",jumpUrl);
              return view;
    	  }
    	  
    	  
      }
	return null;
    	
    }
    
    public byte[] encrypt(RSAPublicKey publicKey, byte[] plainTextData) throws Exception {
        if(publicKey== null){
            throw new Exception("加密公钥为空, 请设置");
        }
        Cipher cipher= null;
        cipher= Cipher.getInstance("RSA", new BouncyCastleProvider());
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] output= cipher.doFinal(plainTextData);
        return output;
    }

    /**
     * String转公钥PublicKey
     * @param key
     * @return
     * @throws Exception
     */
    public static RSAPublicKey getPublicKey(String publicKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
        // 通过X509编码的Key指令获得公钥对象
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(Base64.decodeBase64(publicKey));
        RSAPublicKey key = (RSAPublicKey) keyFactory.generatePublic(x509KeySpec);
        return key;
    }

    
    public void userInfoLogicImp(String mobile, String city) throws Exception {
        LIInvocationContext lic = LIInvocationContext.getContext();
        lic.setUserMobile(mobile);
        lic.setBizCode("login");
        lic.setOpType("login");
        lic.setUserBrand("");
        lic.setUserCity(city);
        InvocationContext ic = new InvocationContext();
        ic.addContextParameter("login_msisdn", mobile);
        ic.addContextParameter("route_type", "2");
        ic.addContextParameter("route_value", mobile);
        lic.setContextParameter(ic);
    }
    
    @RequestMapping("bill.html")
    public ModelAndView bill(HttpServletRequest request, HttpServletResponse response) {
    	logger.info("进入预约页面");
    	String hallNum = request.getParameter("hallNum");
    	String prepairId = prepairService.generateOrderNum();
    	return new ModelAndView("prepairBill").addObject("hallNum",hallNum).addObject("prepairId", prepairId);

    }
    @ResponseBody
    @RequestMapping("insertPic.json")
    public LogicResult insertPic(MultipartFile file, HttpServletRequest request, HttpServletResponse response) throws IllegalStateException, IOException {
        String prepairId = request.getParameter("prepairId");
        
        String originalFilename = file.getOriginalFilename();
        originalFilename =UUID.randomUUID().toString().replace("-", "")+"."+originalFilename.split("\\.")[1];
        System.out.println(originalFilename);
        if(file.getSize()>200000){
        	System.out.println("需要压缩");
        }
        uploadImg(file,WEBApp.getValue("RP.dir")+originalFilename);
        String imgUrl = WEBApp.getValue("RP.url")+originalFilename;
        prepairService.insertImg(prepairId,imgUrl);
        LogicResult result = new LogicResult();
        result.setResult(imgUrl);
        return result;
    }
    @ResponseBody
    @RequestMapping("delPic.json")
    public LogicResult delPic( HttpServletRequest request, HttpServletResponse response) {
    	String prepairId = request.getParameter("prepairId");
    	String imgUrl = "http"+request.getParameter("imgUrl");
    	prepairService.deleteImg(prepairId,imgUrl);
    	
    	LogicResult result = new LogicResult();
    	
    	return result;
    }
    
    @ResponseBody
    @RequestMapping("submit.json")
    public LogicResult submit( HttpServletRequest request, HttpServletResponse response) {
    	LogicResult result = new LogicResult();
      UserInfoBean user = GetUserUtil.getUser(request, response);
    
      String code = request.getParameter("code");
      boolean smsCheckSuccess = false;
      String resultCode = SMSUtil.validateSMSCode(request, user.getMobile(), code);
      if (resultCode.equals(IResultCode.S_OK)) {
          smsCheckSuccess = true;
      } else if (resultCode.equals(ResultCode.SMS_VERIFY_CODE_INVALID)) {
          result.setResMsg("验证码已失效，请重新发送");
          result.setResCode(ResultCode.SMS_VERIFY_CODE_INVALID);
          return result;
      } else if (resultCode.equals(ResultCode.SMS_VERIFY_CODE_WRONG)) {
          result.setResMsg("短信验证码输入错误");
          result.setResCode(ResultCode.SMS_VERIFY_CODE_WRONG);
          return result;
      } 
      
    	PrepairInfoBean prepairInfoBean = new PrepairInfoBean();
    	prepairInfoBean.setHallNum(request.getParameter("hallNum"));
    	prepairInfoBean.setId(request.getParameter("prepairId"));
    	prepairInfoBean.setMemo(request.getParameter("memo"));
    	prepairInfoBean.setMobile(user.getMobile());
    	prepairInfoBean.setName(request.getParameter("name"));
    	prepairInfoBean.setType(request.getParameter("type"));
    	prepairInfoBean.setTime(request.getParameter("time"));
    	if(prepairService.insertPrepairInfo(prepairInfoBean)){
    		result.setResCode(IResultCode.S_OK);
    		//发送商户短信
    		String content ="";
    		String hallNum = request.getParameter("hallNum");
    		String shMobile= prepairService.queryShMobile(hallNum);
        	HallINfoBean hall = prepairService.queryHallInfo(hallNum);
        	content =hall.getName()+"|"+user.getMobile()+"|"+request.getParameter("time")+"|"+request.getParameter("type")+request.getParameter("memo")+"|"+request.getParameter("prepairId");
        	logger.info("商户短信从参数=="+content);
        	sendMessageService.sendMessge(content,shMobile,"openapi_014");
        	//发送用户短信
        	content=user.getMobile()+"|"+hall.getName()+"|"+request.getParameter("prepairId")+"|"+request.getParameter("time")+"|"+hall.getAddress();
        	logger.info("用户短信从参数=="+content);
        	sendMessageService.sendMessge(content,user.getMobile(),"openapi_015");
        	
    		
    	}else{
    		result.setResCode(IResultCode.S_FAIL);
    		result.setResMsg("对不起，预约失败");
    	}
    	
    	return result;
    }
    @ResponseBody
    @RequestMapping("cancel.json")
    public LogicResult cancel( HttpServletRequest request, HttpServletResponse response) {
    	String prepairId = request.getParameter("prepairId");
    	LogicResult result= new LogicResult();
    	if(prepairService.cancelPrepairInfo(prepairId)){
    		result.setResCode(IResultCode.S_OK);
    	}else{
    		result.setResCode(IResultCode.S_FAIL);
    		result.setResMsg("对不起，取消失败");
    	}
    	
    	return result;
    }
   
    
    public void uploadImg(MultipartFile file, String aimFile) throws IOException{
    	float scale=1;
    	if(file.getSize()>200000){
    		scale = 200000f/file.getSize();    		
    	}
    	InputStream is = file.getInputStream();
    	ByteArrayOutputStream out = new ByteArrayOutputStream();
        //压缩输入流，scale是压缩比例；quality是质量比例，0-1之间，越接近1,质量越高
        Thumbnails.of(is).scale(scale).outputQuality(1d).toOutputStream(out);
        InputStream imgInputStream = new ByteArrayInputStream(out.toByteArray());
        is = imgInputStream;
		try {
						
			String path = "";
			for (int i = 0; i < aimFile.split("/").length - 1; i++) {
				path += aimFile.split("/")[i] + "/";
			}
			File tempFile = new File(path);
			if (!tempFile.exists()) {
				tempFile.mkdirs();
			}

			File newFile = new File(aimFile);
			
			 FileOutputStream fos = new FileOutputStream(aimFile);
             //创建一个缓冲区
             byte buffer[] = new byte[1024];
             //判断输入流中的数据是否已经读完的标识
             int length = 0;
             //循环将输入流读入到缓冲区当中，(len=in.read(buffer))>0就表示in里面还有数据
             while((length = is.read(buffer))>0){
                 //使用FileOutputStream输出流将缓冲区的数据写入到指定的目录(savePath + "\\" + filename)当中
                 fos.write(buffer, 0, length);
             }
             //关闭输入流
             is.close();
             //关闭输出流
             fos.close();
             //删除处理文件上传时生成的临时文件
            
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
 			IOUtils.closeQuietly(is);
 		}          
	}
  
  

}
