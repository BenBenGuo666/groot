select * from TO_ORDERDIAL_SUB t order by f_order_sub_num desc;
select * from TO_ORDERINIT_MAIN;
select * from TO_ORDERINIT_SUB;
select * from TO_ORDERSALE_PAYLOG;
select * from to_ordersale_main order by f_order_number desc;

select * from to_ordersale_main where f_order_number = 'B20211021192352171726';

select * from TO_ORDERSALE_PAYLOG where F_XX_PAY_MODE is not null and rownum = 1;
select a.rowid,a.* from TB_DA_PROV_GOODS a where f_goods_num = 'JSYD-DDSCSPP-CSXH30-8-256-11';

select * from TB_GOODS_IMEI_LOG order by f_last_time desc
select * from TB_DA_PROV_GOODS


select * from TO_ORDERDIAL_SUB_DETAIL

select * from to_orderdial_main;

PKG_DIALORDER_ALL.P_DIALORDER_BUILD_PRE

-- ��ѯ invocation
select * from T_LINTERFACE_DA where f_li_number = 'B2B_ORDERDAIL_CONFIRM';

select * from tb_goods_sn where F_REGION_NUM = '931945' and rownum < 1000;


 SELECT MAX(A.F_PZONE_NUM) ACTIVATENUM FROM 
 XW_PZONE_INFO A, XW_PZONE_GOODS B, TO_THD_GOODS_DETAIL C,XW_PZONE_REGION D   
 WHERE A.F_PZONE_NUM = B.F_PZONE_NUM AND A.F_PZONE_NUM = D.F_PZONE_NUM   
 AND B.F_GOODS_NUM = C.F_SPU_ID   AND TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') 
 BETWEEN F_START_TIME AND F_END_TIME   AND A.F_PZONE_STATUS = '2'   
 AND C.F_SKU_ID = ''   AND D.F_REGION_NUM = ''   AND B.F_SUPP_NUM = ''
 
 select * from XW_PZONE_GOODS
select * from TI_REGION_IMEI_DETAIL


SELECT COUNT(1) NOAUTH_COUNT   FROM TI_REGION_IMEI_DETAIL A
 WHERE NOT EXISTS (SELECT 1  FROM TB_GOODS_IMEI B  WHERE A.F_GOODS_IMEI 
 = B.F_IMEI AND B.F_IS_AUTH = 1)   AND A.F_SERIAL_NUM = '2021110420244761818059'

SELECT * FROM TB_GOODS_IMEI

SELECT *  FROM TB_GOODS_IMEI B  WHERE B.F_IS_AUTH = 0

select A.F_GOODS_IMEI, B.F_IMEI, B.F_IS_AUTH from TI_REGION_IMEI_DETAIL A
left join TB_GOODS_IMEI B on A.F_GOODS_IMEI = B.F_IMEI 
where A.F_SERIAL_NUM = '2021110420244761818059' order by A.f_serial_num desc

B2B_REGION_ORDER_SIGN
SELECT * FROM T_LINTERFACE_DA WHERE F_LI_NUMBER LIKE '%SIGN%'
SELECT * FROM T_LINTERFACE_DA WHERE F_LI_NUMBER = 'B2B_DIST_IMEI_DIST'

select a.rowId,a.* from tb_da_goodstype a inner join tb_da_goods b on a.f_goods_type_num = b.f_goods_type_num and b.f_goods_num = 'JSYD-DDSCSPP-CSXH30-8-128-11'

select F_IS_CELLPHONE from xw_check_imei a 
inner join tb_da_goods b on a.f_goods_num = b.f_goods_num and a.F_BATCH_NUM = '20210915110921411554'
inner join tb_da_goodstype c on b.f_goods_type_num = c.f_goods_type_num
where rownum = 1
select * from xw_check_imei a where F_EXT_VAL2 is not null
select * from tb_da_goods a 
SELECT * FROM TB_DA_GOODSTYPE
select * from tb_goods_sn;

select * from TB_GOODS_SN_LOG

-- �̻��ֻ���������Ҫ���������������κ��������� goods sn ����
insert into TB_GOODS_SN_LOG T(
      F_SN_LOG_ID, F_RECORD_TIME,
      F_BILL_NUM,F_BILL_TYPE, 
      F_SN, F_REGION_NUM, 
      F_GOODS_NUM, F_SUPPLIER_NUM, F_SUPP_TYPE, 
      F_ORG_NUM, F_SN_STATUS, F_STOCK_TYPE_NUM, 
      F_STOCK_MODE, F_IS_USE, F_ORDER_PRICE,F_DIST_PRICE,
      F_RETAIL_PRICE, F_INWARE_TIME,
      F_IS_FREEZE, F_LAST_MANCODE, F_LAST_MANNAME, 
      F_LAST_TIME, F_LAST_MEMO, F_IS_BUYOUT, 
      F_CHANNEL_TYPE, F_SIGN_TIME, F_IS_AUTH, 
      F_BATCH_NUM, F_INSTORE_TYPE, 
      F_UP_STOCK_MODE, F_IS_MIS, 
      F_IS_SETTLED, F_IS_ACTIVATED
      )
select TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') || SEQ_IMEI_LOG.NEXTVAL, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'),
      checkI.F_BATCH_NUM,'B2B',
      checkI.F_GOODS_IMEI, org.F_REGION_NUM, 
      checkI.F_GOODS_NUM, checkI.F_CHECK_MANCODE F_SUPPLIER_NUM, 1, 
      org.F_CHANNEL_CODE F_ORG_NUM, 'PSZT', 'ZPK', 
      1, 1, 0.00, 0.00,
      0.00, TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),
      0, checkI.F_CHECK_MANCODE F_LAST_MANCODE, checkI.F_CHECK_MANNAME F_LAST_MANNAME, 
      TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'), '�̻��ֻ�����', 0, 
      '99', TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'), 0, 
      checkI.F_BATCH_NUM, 0,
      '1', 0,
      0, 0
      from xw_check_imei checkI 
      inner join TB_DA_PROV_ORG org ON checkI.F_BATCH_NUM = '20210915110921411554' AND org.F_CHANNEL_CODE = checkI.F_EXT_VAL2;

-- �̻��ֻ���������Ҫ���������������κ��������� goods sn ����
insert into TB_GOODS_SN T(F_SN, F_REGION_NUM, 
      F_GOODS_NUM, F_SUPPLIER_NUM, F_SUPP_TYPE, 
      F_ORG_NUM, F_SN_STATUS, F_STOCK_TYPE_NUM, 
      F_STOCK_MODE, F_IS_USE, F_ORDER_PRICE,F_DIST_PRICE,
      F_RETAIL_PRICE, F_INWARE_TIME,
      F_IS_FREEZE, F_LAST_MANCODE, F_LAST_MANNAME, 
      F_LAST_TIME, F_LAST_MEMO, F_IS_BUYOUT, 
      F_CHANNEL_TYPE, F_SIGN_TIME, F_IS_AUTH, 
      F_BATCH_NUM, F_INSTORE_TYPE, 
      F_UP_STOCK_MODE, F_IS_MIS, 
      F_IS_SETTLED, F_IS_ACTIVATED
      )
select checkI.F_GOODS_IMEI, org.F_REGION_NUM, 
      checkI.F_GOODS_NUM, checkI.F_CHECK_MANCODE F_SUPPLIER_NUM, 1, 
      org.F_CHANNEL_CODE F_ORG_NUM, 'PSZT', 'ZPK', 
      1, 1, 0.00, 0.00,
      0.00, TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),
      0, checkI.F_CHECK_MANCODE F_LAST_MANCODE, checkI.F_CHECK_MANNAME F_LAST_MANNAME, 
      TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'), '�̻��ֻ�����', 0, 
      '99', TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'), 0, 
      checkI.F_BATCH_NUM, 0,
      '1', 0,
      0, 0
      from xw_check_imei checkI 
      inner join TB_DA_PROV_ORG org ON checkI.F_BATCH_NUM = '20210915110921411554' AND org.F_CHANNEL_CODE = checkI.F_EXT_VAL2;
      
      
-- ��ȫ����
-- �����Ǳ���ͳ��
-- ʡ��Ҫ���ṩ���ۻ��ܷ���ͳ��
select * from UTMS_PROV_ORDER_SUM_DAY;
-- ʡ��Ҫ���ṩ���ۻ��ܷ���ͳ��
select a.rowId,a.* from UTMS_PROV_ORDER_SUM_DAY a;



--ͷ����Ϣ
SELECT A.totalGoods,
       ((100*round(A.totalGoods/SUM(B.F_GOODS_COUNT) OVER(),2) - 100)||'%') ratioGoods,
       A.totalDeliv,
       ((100*round(A.totalGoods/SUM(B.F_GOODS_COUNT) OVER(),2) - 100)||'%') ratioDeliv,
       A.totalOrder,
       ((100*round(A.totalGoods/SUM(B.F_GOODS_COUNT) OVER(),2) - 100)||'%') ratioOrder,
       A.totalSale,
       ((100*round(A.totalGoods/SUM(B.F_GOODS_COUNT) OVER(),2) - 100)||'%') ratioSale,
       A.totalSaleMoney,
       ((100*round(A.totalGoods/SUM(B.F_GOODS_COUNT) OVER(),2) - 100)||'%') ratioSaleMoney
 FROM(
SELECT SUM(o.F_GOODS_COUNT) totalGoods,
       SUM(o.F_DELIV_COUNT) totalDeliv,
       SUM(o.F_ORDER_COUNT) totalOrder,
       SUM(o.F_SALE_COUNT) totalSale,
       SUM(o.F_SALE_MONEY) totalSaleMoney
  FROM UTMS_PROV_ORDER_SUM_DAY o
 WHERE o.F_DAY = '20211111') A,
 UTMS_PROV_ORDER_SUM_DAY B
WHERE B.F_DAY = ('20211111' - 1);
select * from UTMS_PROV_ORDER_SUM_DAY B
        WHERE B.F_DAY = ('20211112' - 1) AND ROWNUM = 1

SELECT          round(A.totalGoods/10000, 1) totalGoods,
               ((100 * round(A.totalGoods / b.totalGoods, 2) - 100) || '%') ratioGoods,
               round(A.totalDeliv/10000, 1) totalDeliv,
               ((100 * round(A.totalDeliv / b.totalGoods, 2) - 100) || '%') ratioDeliv,
               round(A.totalOrder/10000, 1) totalOrder,
               ((100 * round(A.totalOrder / b.totalGoods, 2) - 100) || '%') ratioOrder,
               round(A.totalSale/10000, 1) totalSale,
               ((100 * round(A.totalSale / b.totalGoods, 2) - 100) || '%') ratioSale,
               round(A.totalSaleMoney/10000, 1) totalSaleMoney,
               ((100 * round(A.totalSaleMoney / b.totalGoods, 2) - 100) || '%') ratioSaleMoney
        FROM (
                 SELECT SUM(o.F_GOODS_COUNT) totalGoods,
                        SUM(o.F_DELIV_COUNT) totalDeliv,
                        SUM(o.F_ORDER_COUNT) totalOrder,
                        SUM(o.F_SALE_COUNT)  totalSale,
                        SUM(o.F_SALE_MONEY)  totalSaleMoney
                 FROM UTMS_PROV_ORDER_SUM_DAY o
                 WHERE o.F_DAY = '20211112') A,
                 (
                 SELECT SUM(o.F_GOODS_COUNT) totalGoods,
                        SUM(o.F_DELIV_COUNT) totalDeliv,
                        SUM(o.F_ORDER_COUNT) totalOrder,
                        SUM(o.F_SALE_COUNT)  totalSale,
                        SUM(o.F_SALE_MONEY)  totalSaleMoney
                 FROM UTMS_PROV_ORDER_SUM_DAY o
                 WHERE o.F_DAY = ('20211112' - 1)) b

--ʡ����ϸ�б� 
SELECT A.F_PROV_NUM,
       A.F_PROV_NAME,
       (A.F_GOODS_COUNT) ������,
       (A.F_DELIV_COUNT) �����,
       (A.F_ORDER_COUNT) ������,
       (A.F_SALE_COUNT) ����,
       (A.F_SALE_MONEY) ���۶�
  FROM UTMS_PROV_ORDER_SUM_DAY A
 WHERE A.F_DAY = '20211110';

SELECT SUM(A.F_SIGN_COUNT - A.F_SALE_COUNT - A.F_RETURN_COUNT) F_CHANGE_COUNT
        FROM UTMS_PROV_GOODS_PSSM A
        WHERE A.F_DAY = TO_CHAR(SYSDATE, 'YYYYMMDDHH')

--����TOP
--������������
--���۶�TOP
--�������۶�����

-- �����:���տ���� + ���췢����
--- ���տ����
SELECT SUM(A.F_STOCK_COUNT) F_STOCK_COUNT FROM UTMS_PROV_GOODS_STOCK A;
SELECT round(SUM(A.F_STOCK_COUNT)/10000,1) F_STOCK_COUNT
        FROM UTMS_PROV_GOODS_STOCK_DAY A
        WHERE A.F_DAY = '20211112'
-- ���췢����
SELECT SUM(A.F_SIGN_COUNT - A.F_SALE_COUNT - A.F_RETURN_COUNT) F_CHANGE_COUNT
  FROM UTMS_PROV_GOODS_PSSM A
 WHERE A.F_DAY = '20211112';
select TO_CHAR(SYSDATE, 'YYYYMMDDHH') from dual; 

SELECT SUM(A.F_SIGN_COUNT - A.F_SALE_COUNT - A.F_RETURN_COUNT) F_CHANGE_COUNT
  FROM UTMS_PROV_GOODS_PSSM A
 WHERE A.F_DAY = '20211110';
select * from UTMS_PROV_GOODS_PSSM
--Ҫ���������Ϣ
SELECT A.F_CHANNELTYPE_NAME,
       A.F_CHANNELTYPE,
       A.totalGoods,
       ((100 * round(A.totalGoods / A.total, 2)) || '%') ratioGoods,
       A.totalDeliv,
       ((100 * round(A.totalDeliv / A.total, 2)) || '%') ratioDeliv,
       A.totalOrder,
       ((100 * round(A.totalOrder / A.total, 2)) || '%') ratioOrder,
       A.total
FROM (SELECT 
       A.F_CHANNELTYPE_NAME,
       A.F_CHANNELTYPE,
       A.totalGoods,
       A.totalDeliv,
       A.totalOrder,
       (totalGoods + totalDeliv + totalOrder) total
 FROM (
SELECT F_CHANNELTYPE_NAME,
       F_CHANNELTYPE,
       SUM(A.F_GOODS_COUNT) totalGoods,
       SUM(A.F_DELIV_COUNT) totalDeliv,
       SUM(A.F_ORDER_COUNT) totalOrder
  FROM UTMS_PROV_ORDER_CHANNELTYPE_DAY A
 WHERE A.F_DAY = '20211111'
 GROUP BY F_CHANNELTYPE_NAME, F_CHANNELTYPE) a)a
 
 
 select a.rowid,a.* from UTMS_PROV_ORDER_CHANNELTYPE_DAY a;
 --�����TOP
SELECT A.F_BRAND_NAME,
         A.F_GOODS_MODEL , SUM(F_STOCK_COUNT) totalStock  FROM (
SELECT A.F_BRAND_NAME, A.F_GOODS_MODEL, SUM(A.F_STOCK_COUNT) F_STOCK_COUNT
  FROM UTMS_PROV_GOODS_STOCK A
 group by A.F_BRAND_NAME, A.F_GOODS_MODEL
union all
  SELECT A.F_BRAND_NAME,
         A.F_GOODS_MODEL,
         SUM(A.F_SIGN_COUNT - A.F_SALE_COUNT - A.F_RETURN_COUNT) F_CHANGE_COUNT
    FROM UTMS_PROV_GOODS_PSSM A
   WHERE A.F_DAY = '20211110'
   group by A.F_BRAND_NAME, A.F_GOODS_MODEL
 ) A 
 WHERE ROWNUM <= 10
 GROUP BY A.F_BRAND_NAME,
         A.F_GOODS_MODEL
 ORDER BY 3 DESC

--����TOP
SELECT A.F_BRAND_NAME, A.F_GOODS_MODEL, SUM(F_SALE_COUNT) F_SALE_COUNT
  FROM UTMS_PROV_GOODS_PSSM A
 WHERE A.F_DAY = '20211112'
 group by A.F_BRAND_NAME, A.F_GOODS_MODEL
 order by 3 desc;
 
 SELECT SUM(A.F_STOCK_COUNT) F_STOCK_COUNT FROM UTMS_PROV_GOODS_STOCK_DAY A WHERE A.F_DAY = '20211112'
 
 SELECT SUM(A.F_SIGN_COUNT - A.F_SALE_COUNT - A.F_RETURN_COUNT) F_CHANGE_COUNT FROM UTMS_PROV_GOODS_PSSM A WHERE A.F_DAY = TO_CHAR(SYSDATE, 'YYYYMMDDHH') 
