/*
 Navicat Premium Data Transfer

 Source Server         : tz_platform
 Source Server Type    : MySQL
 Source Server Version : 50635
 Source Host           : 192.168.20.126:3306
 Source Schema         : djdemo

 Target Server Type    : MySQL
 Target Server Version : 50635
 File Encoding         : 65001

 Date: 20/07/2021 14:08:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tsys_resource
-- ----------------------------
DROP TABLE IF EXISTS `tsys_resource`;
CREATE TABLE `tsys_resource`  (
  `F_RESOURCE_NUM` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '资源编码 建议编码前缀使用应用缩写 如 SYS+ ****',
  `F_APP_NUM` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '应用编码 TSYS_APPLICATION 主键',
  `F_RESOURCE_NAME` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '资源名称',
  `F_RESOURCE_TYPE` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '资源类型 MODULE-模块 MENU-菜单 BUTTON- 按钮用于对按钮权限控制时使用该类型',
  `F_RESOURCE_URL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '资源访问地址,不要配置完整的url地址，只填写url应用名称后信息',
  `F_PARENT_NUM` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '直接父级编码',
  `F_PERMISSION` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '菜单权限编码定义如 user:* 代表用户管理功能所有权限',
  `F_IS_USE` decimal(1, 0) NULL DEFAULT 1 COMMENT '是否可用 0 否 1 是',
  `F_STYLE_CLASS` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '菜单图标css样式',
  `F_SORT` decimal(5, 0) NULL DEFAULT NULL COMMENT '菜单显示顺序',
  `F_ICON_URL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '图标地址',
  PRIMARY KEY (`F_RESOURCE_NUM`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '系统应用资源档案表（菜单）' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tsys_resource
-- ----------------------------
INSERT INTO `tsys_resource` VALUES ('SYS_GL', 'produce-manage', '概览', 'MODULE', '', '0', 'index', 1, 'el-icon-xa xa-icon xa-icon-home', 1, '');
INSERT INTO `tsys_resource` VALUES ('SYS_JSGL', 'produce-manage', '角色管理', 'MENU', '/role/index', 'SYS_YHGL', 'use:role', 1, '', 2, '');
INSERT INTO `tsys_resource` VALUES ('SYS_JSSC', 'produce-manage', '角色删除', 'BUTTON', '', 'SYS_JSGL', 'delete:role:user', 1, '', 1, '');
INSERT INTO `tsys_resource` VALUES ('SYS_JSXG', 'produce-manage', '角色修改', 'BUTTON', '', 'SYS_JSGL', 'edit:role:user', 1, '', 1, '');
INSERT INTO `tsys_resource` VALUES ('SYS_JSXZ', 'produce-manage', '角色新增', 'BUTTON', '', 'SYS_JSGL', 'add:role:user', 1, '', 1, '');
INSERT INTO `tsys_resource` VALUES ('SYS_JSZT', 'produce-manage', '角色状态', 'BUTTON', '', 'SYS_JSGL', 'status:role:user', 1, '', 1, '');
INSERT INTO `tsys_resource` VALUES ('SYS_ORGGL', 'produce-manage', '组织管理', 'MENU', '/org/index', 'SYS_YHGL', 'user:org', 1, '', 3, NULL);
INSERT INTO `tsys_resource` VALUES ('SYS_ORGSC', 'produce-manage', '组织删除', 'BUTTON', NULL, 'SYS_ORGGL', 'delete:org:user', 1, NULL, 1, NULL);
INSERT INTO `tsys_resource` VALUES ('SYS_ORGXG', 'produce-manage', '组织修改', 'BUTTON', NULL, 'SYS_ORGGL', 'edit:org:user', 1, NULL, 3, NULL);
INSERT INTO `tsys_resource` VALUES ('SYS_ORGXZ', 'produce-manage', '组织新增', 'BUTTON', ' ', 'SYS_ORGGL', 'add:org:user', 1, NULL, 2, NULL);
INSERT INTO `tsys_resource` VALUES ('SYS_ORGZT', 'produce-manage', '组织状态', 'BUTTON', NULL, 'SYS_ORGGL', 'status:org:user', 1, NULL, 4, NULL);
INSERT INTO `tsys_resource` VALUES ('SYS_QXGL', 'produce-manage', '权限管理', 'MENU', '/menu/permission', 'SYS_XTGL', 'sys:permission', 1, '', 2, '');
INSERT INTO `tsys_resource` VALUES ('SYS_XTGL', 'produce-manage', '系统管理', 'MODULE', '', '0', 'sys', 1, 'el-icon-xa el-icon-setting', 4, '');
INSERT INTO `tsys_resource` VALUES ('SYS_YHGL', 'produce-manage', '用户管理', 'MODULE', '', '0', 'user', 1, 'el-icon-xa xa-icon xa-icon-user', 2, '');
INSERT INTO `tsys_resource` VALUES ('SYS_YHHGL', 'produce-manage', '用户管理', 'MENU', '/user/index', 'SYS_YHGL', 'user:user', 1, '', 1, '');
INSERT INTO `tsys_resource` VALUES ('SYS_YHSC', 'produce-manage', '用户删除', 'BUTTON', '', 'SYS_YHHGL', 'delete:user:user', 1, '', 0, '');
INSERT INTO `tsys_resource` VALUES ('SYS_YHXG', 'produce-manage', '用户修改', 'BUTTON', '', 'SYS_YHHGL', 'edit:user:user', 1, '', 1, '');
INSERT INTO `tsys_resource` VALUES ('SYS_YHXZ', 'produce-manage', '用户新增', 'BUTTON', '', 'SYS_YHHGL', 'add:user:user', 1, '', 0, '');
INSERT INTO `tsys_resource` VALUES ('SYS_YHZT', 'produce-manage', '用户状态', 'BUTTON', '', 'SYS_YHHGL', 'status:user:user', 1, '', 0, '');
INSERT INTO `tsys_resource` VALUES ('SYS_ZHSC', 'produce-manage', '账户删除', 'BUTTON', '', 'SYS_YHHGL', 'delete:account:user', 1, '', 0, '');
INSERT INTO `tsys_resource` VALUES ('SYS_ZHXG', 'produce-manage', '账户修改', 'BUTTON', '', 'SYS_YHHGL', 'edit:account:user', 1, '', 0, '');
INSERT INTO `tsys_resource` VALUES ('SYS_ZHXZ', 'produce-manage', '账户新增', 'BUTTON', '', 'SYS_YHHGL', 'add:account:user', 1, '', 0, '');
INSERT INTO `tsys_resource` VALUES ('SYS_ZHZT', 'produce-manage', '账户状态', 'BUTTON', '', 'SYS_YHHGL', 'status:account:user', 1, '', 0, '');
INSERT INTO `tsys_resource` VALUES ('SYS_ZYGL', 'produce-manage', '资源管理', 'MENU', '/menu/index', 'SYS_XTGL', 'sys:resource', 1, '', 1, '');

SET FOREIGN_KEY_CHECKS = 1;
