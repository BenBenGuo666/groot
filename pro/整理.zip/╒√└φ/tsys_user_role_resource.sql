/*
 Navicat Premium Data Transfer

 Source Server         : tz_platform
 Source Server Type    : MySQL
 Source Server Version : 50635
 Source Host           : 192.168.20.126:3306
 Source Schema         : djdemo

 Target Server Type    : MySQL
 Target Server Version : 50635
 File Encoding         : 65001

 Date: 20/07/2021 14:08:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tsys_user_role_resource
-- ----------------------------
DROP TABLE IF EXISTS `tsys_user_role_resource`;
CREATE TABLE `tsys_user_role_resource`  (
  `F_AUTH_ID` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '授权用户ID或角色ID',
  `F_RESOURCE_NUM` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '系统资源编码',
  `F_TYPE` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '类型  ROLE-针对角色配置菜单权限 USER-单独用户配置菜单权限',
  `F_CTRL_TYPE` decimal(1, 0) NOT NULL DEFAULT 1 COMMENT '控制类型 1:启用 0:禁用   \n             1:标识授权ID可以拥有其权限 \n             0:标识其禁止相关权限 \n             应用场景:角色或部门通用权限下 限制某个用户不允许拥有通用权限',
  PRIMARY KEY (`F_AUTH_ID`, `F_RESOURCE_NUM`, `F_TYPE`, `F_CTRL_TYPE`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '用户角色资源对照关系表（可以是用户、角色）' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tsys_user_role_resource
-- ----------------------------
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_GL', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_JSGL', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_JSSC', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_JSXG', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_JSXZ', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_JSZT', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ORGGL', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ORGSC', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ORGXG', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ORGXZ', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ORGZT', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_QXGL', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_XTGL', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_YHGL', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_YHHGL', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_YHSC', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_YHXG', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_YHXZ', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_YHZT', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ZHSC', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ZHXG', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ZHXZ', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ZHZT', 'ROLE', 1);
INSERT INTO `tsys_user_role_resource` VALUES ('TR000001', 'SYS_ZYGL', 'ROLE', 1);

SET FOREIGN_KEY_CHECKS = 1;
