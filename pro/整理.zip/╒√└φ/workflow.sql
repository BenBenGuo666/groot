/*
 Navicat Premium Data Transfer

 Source Server         : 本地Mysql_8.0.25
 Source Server Type    : MySQL
 Source Server Version : 80025
 Source Host           : localhost:3306
 Source Schema         : workflow

 Target Server Type    : MySQL
 Target Server Version : 80025
 File Encoding         : 65001

 Date: 24/06/2021 14:27:56
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for node
-- ----------------------------
DROP TABLE IF EXISTS `node`;
CREATE TABLE `node`  (
  `node_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '节点唯一标识',
  `node_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点名称',
  `node_type` int(0) NULL DEFAULT NULL COMMENT '节点类型：0.默认节点 1.集合节点 2.子流程节点',
  `node_prev` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '上一个节点',
  `node_next` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '下一个节点',
  `node_backed` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '回退节点',
  `node_parent` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '父节点',
  `node_expression` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '进入节点表达式',
  `workflow_code_and_node_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程唯一标识',
  `node_createtime` datetime(0) NULL DEFAULT NULL COMMENT '节点创建时间',
  `node_creator` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点创建人',
  `node_modifytime` datetime(0) NULL DEFAULT NULL COMMENT '节点修改时间',
  `node_modifier` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点修改人',
  `node_permission` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点权限，逗号分割：U开头对人，G开头对组织，R开头对角色',
  `node_status` int(0) NULL DEFAULT NULL COMMENT '-1.失效的 0.等待开始 1.开始中 2.已结束 3.已回退 4.挂起 5.阻塞 ',
  `node_remarke` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点备注',
  `node_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '节点对应功能页面 url',
  `node_flag` int(0) NULL DEFAULT NULL COMMENT '0.删除的 1.正常的',
  `serial_number` int(0) NULL DEFAULT NULL COMMENT '序号',
  `node_classify` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'HEAD;TAIL;',
  PRIMARY KEY (`node_code`) USING BTREE,
  INDEX `流程唯一标识外键`(`workflow_code_and_node_code`) USING BTREE,
  INDEX `node_code`(`node_code`) USING BTREE,
  INDEX `父节点标识`(`node_parent`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of node
-- ----------------------------
INSERT INTO `node` VALUES ('N03971bcd2fac12b', '开始', 0, NULL, 'Na686812930cb67a', NULL, NULL, NULL, 'F3e80a7905ec51bf', '2021-06-18 16:51:39', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N084561133d6ad28', '开始', 0, NULL, 'N71b2e35ad22e983', NULL, NULL, NULL, 'Fc801614c012b08e', '2021-06-17 14:52:12', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N09442ac809da9bc', '节点测试13', 0, 'Nae605c6420dbd84', 'Ncd9619e8398f31c', NULL, '', NULL, 'Z554c9781360e8c5', '2021-06-22 20:17:49', 'admin', '2021-06-22 20:17:49', 'admin', '1001,1002', 0, NULL, 'https://www.baidu.com/', 1, NULL, NULL);
INSERT INTO `node` VALUES ('N160c27abfbbedef', '开始', 0, NULL, 'N969132522ea977d', NULL, NULL, NULL, 'F119fc9ff7cfab45', '2021-06-18 16:51:31', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N18972d42b30ac5f', '结束', 0, 'N32bba2b97ce9d3c', NULL, NULL, NULL, NULL, 'F9605f6855c47801', '2021-06-17 14:52:38', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N21042fe00c61c8e', '结束', 0, 'N5b142f8624a9afa', NULL, NULL, NULL, NULL, 'F006099596ef5a6e', '2021-06-18 16:51:47', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N2304b9053486e94', '结束', 0, 'N9cd9f9746c5890e', NULL, NULL, NULL, NULL, 'Fe47489a8ee469ba', '2021-06-17 14:52:25', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N2ff52aa44d3cf3e', '开始', 0, NULL, 'N8a283cbfae4fe15', NULL, NULL, NULL, 'Ffa6d87d261474e3', '2021-06-17 14:52:45', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N32bba2b97ce9d3c', '开始', 0, NULL, 'N18972d42b30ac5f', NULL, NULL, NULL, 'F9605f6855c47801', '2021-06-17 14:52:38', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N4421f747363dbb2', '开始', 0, NULL, 'N85890bc5365f23a', NULL, NULL, NULL, 'Ff03955a77cdfdb4', '2021-06-22 20:16:47', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N4539debbff346af', '结束', 0, 'N5b0e9fff4715ebe', NULL, NULL, NULL, NULL, 'F64cfbc9d9c77199', '2021-06-17 14:52:32', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N45c60eeba939af9', '结束', 0, 'N8353ae2ef1d8866', NULL, NULL, NULL, NULL, 'F7d7079daceb2eab', '2021-06-18 16:51:43', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N4a8000f95c2bb4a', '开始', 0, NULL, 'Nd37dbb8c03f9961', NULL, NULL, NULL, 'F85b3e91d3c0d685', '2021-06-17 14:52:55', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N4f00c1aec81d867', '结束', 0, 'Nf07ab0a14a86684', NULL, NULL, NULL, NULL, 'F5fc8a3bf24579cb', '2021-06-17 14:52:07', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N51d34748e03f762', '节点测试11', 0, '', 'Nae605c6420dbd84', NULL, '', NULL, 'Z554c9781360e8c5', '2021-06-22 20:17:49', NULL, '2021-06-22 20:17:49', 'admin', '', 0, NULL, 'https://www.baidu.com/', 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N558b90d9e9c226e', '结束', 0, 'N992f98c9f7c9eb0', NULL, NULL, NULL, NULL, 'F7e5afd613f97b9e', '2021-06-09 16:16:12', NULL, '2021-06-09 16:16:12', 'admin', NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N5b0e9fff4715ebe', '开始', 0, NULL, 'N4539debbff346af', NULL, NULL, NULL, 'F64cfbc9d9c77199', '2021-06-17 14:52:32', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N5b142f8624a9afa', '开始', 0, NULL, 'N21042fe00c61c8e', NULL, NULL, NULL, 'F006099596ef5a6e', '2021-06-18 16:51:47', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N67d386c6d2773a0', '节点测试16', 0, 'Ncd9619e8398f31c', 'Ne971c6705ebe7e4', NULL, NULL, NULL, 'Z554c9781360e8c5', '2021-06-22 20:17:49', NULL, '2021-06-22 20:17:49', 'admin', NULL, 0, NULL, NULL, 1, NULL, '');
INSERT INTO `node` VALUES ('N71b2e35ad22e983', '结束', 0, 'N084561133d6ad28', NULL, NULL, NULL, NULL, 'Fc801614c012b08e', '2021-06-17 14:52:12', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N8353ae2ef1d8866', '开始', 0, NULL, 'N45c60eeba939af9', NULL, NULL, NULL, 'F7d7079daceb2eab', '2021-06-18 16:51:43', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N85890bc5365f23a', '结束', 0, 'N4421f747363dbb2', NULL, NULL, NULL, NULL, 'Ff03955a77cdfdb4', '2021-06-22 20:16:47', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N8a283cbfae4fe15', '结束', 0, 'N2ff52aa44d3cf3e', NULL, NULL, NULL, NULL, 'Ffa6d87d261474e3', '2021-06-17 14:52:45', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N8aff4d8da6ed9d3', '结束', 0, 'N9b307edbc73e854', NULL, NULL, NULL, NULL, 'F1ceaff17dbbee39', '2021-06-17 14:52:51', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N8c0380d8367b1fd', '节点测试14', 0, 'Ne971c6705ebe7e4', '', NULL, '', NULL, 'Z554c9781360e8c5', '2021-06-22 20:17:49', 'admin', '2021-06-22 20:17:49', 'admin', '1001,1002', 0, NULL, 'https://www.baidu.com/', 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N969132522ea977d', '结束', 0, 'N160c27abfbbedef', NULL, NULL, NULL, NULL, 'F119fc9ff7cfab45', '2021-06-18 16:51:31', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('N992f98c9f7c9eb0', '节点1', 0, 'Nf77ca5d439b48fa', 'N558b90d9e9c226e', '', NULL, NULL, 'F7e5afd613f97b9e', '2021-06-09 16:16:12', NULL, '2021-06-09 16:16:12', 'admin', '', 0, NULL, NULL, 1, NULL, '');
INSERT INTO `node` VALUES ('N9b307edbc73e854', '开始', 0, NULL, 'N8aff4d8da6ed9d3', NULL, NULL, NULL, 'F1ceaff17dbbee39', '2021-06-17 14:52:51', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('N9cd9f9746c5890e', '开始', 0, NULL, 'N2304b9053486e94', NULL, NULL, NULL, 'Fe47489a8ee469ba', '2021-06-17 14:52:25', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('Na686812930cb67a', '结束', 0, 'N03971bcd2fac12b', NULL, NULL, NULL, NULL, 'F3e80a7905ec51bf', '2021-06-18 16:51:39', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('Na8430bd35c70278', '开始', 0, NULL, 'Ne5514c8a9d4a29c', NULL, NULL, NULL, 'F40ec0bfc62eb2b3', '2021-06-17 14:52:18', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('Nae605c6420dbd84', '节点测试12', 0, 'N51d34748e03f762', 'N09442ac809da9bc', NULL, '', NULL, 'Z554c9781360e8c5', '2021-06-22 20:17:49', 'admin', '2021-06-22 20:17:49', 'admin', '1001,1002', 0, NULL, 'https://www.baidu.com/', 1, NULL, NULL);
INSERT INTO `node` VALUES ('Ncaf157cf8140e76', '节点测试18', 0, 'N51d34748e03f762', 'Nae605c6420dbd84', 'Ncaf157cf8140e76', NULL, NULL, 'Z554c9781360e8c5', '2021-06-21 17:49:59', NULL, '2021-06-21 17:49:59', 'admin', 'U1001,R1002', 0, NULL, NULL, 0, NULL, '');
INSERT INTO `node` VALUES ('Ncc2c931c176cf69', '节点测试17', 0, 'N67d386c6d2773a0', 'N8c0380d8367b1fd', 'Ncaf157cf8140e76', NULL, NULL, 'Z554c9781360e8c5', '2021-06-21 17:55:57', NULL, '2021-06-21 17:55:57', 'admin', NULL, 0, NULL, NULL, 0, NULL, '');
INSERT INTO `node` VALUES ('Ncd9619e8398f31c', '节点测试15', 0, 'N09442ac809da9bc', 'N67d386c6d2773a0', NULL, '', NULL, 'Z554c9781360e8c5', '2021-06-22 20:17:49', 'admin', '2021-06-22 20:17:49', 'admin', '1001,1002', 0, NULL, 'https://www.baidu.com/', 1, NULL, NULL);
INSERT INTO `node` VALUES ('Nd37dbb8c03f9961', '结束', 0, 'N4a8000f95c2bb4a', NULL, NULL, NULL, NULL, 'F85b3e91d3c0d685', '2021-06-17 14:52:55', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('Ne5514c8a9d4a29c', '结束', 0, 'Na8430bd35c70278', NULL, NULL, NULL, NULL, 'F40ec0bfc62eb2b3', '2021-06-17 14:52:18', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'TAIL');
INSERT INTO `node` VALUES ('Ne971c6705ebe7e4', '节点测试20', 0, 'N67d386c6d2773a0', 'N8c0380d8367b1fd', 'Nae605c6420dbd84', NULL, NULL, 'Z554c9781360e8c5', '2021-06-22 20:17:49', NULL, '2021-06-22 20:17:49', 'admin', '', 0, NULL, '', 1, NULL, '');
INSERT INTO `node` VALUES ('Nf07ab0a14a86684', '开始', 0, NULL, 'N4f00c1aec81d867', NULL, NULL, NULL, 'F5fc8a3bf24579cb', '2021-06-17 14:52:07', NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 'HEAD');
INSERT INTO `node` VALUES ('Nf77ca5d439b48fa', '开始', 0, NULL, 'N992f98c9f7c9eb0', NULL, NULL, NULL, 'F7e5afd613f97b9e', '2021-06-09 16:16:12', NULL, '2021-06-09 16:16:12', 'admin', NULL, 0, NULL, NULL, 1, NULL, 'HEAD');

-- ----------------------------
-- Table structure for work_order
-- ----------------------------
DROP TABLE IF EXISTS `work_order`;
CREATE TABLE `work_order`  (
  `wo_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '工单唯一标识',
  `node_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程节点唯一标识',
  `wo_status` int(0) NULL DEFAULT NULL COMMENT '-1.失效的 0.待开始 1.审核中 2.已审核 3.已回退 4.已挂起 5.已阻塞 6.等待中',
  `wo_reviewers` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '审核人',
  `wo_situation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '工单现状',
  `wo_createtime` datetime(0) NULL DEFAULT NULL COMMENT '工单创建时间',
  `wo_updatetime` datetime(0) NULL DEFAULT NULL COMMENT '工单更新时间',
  `wo_flag` int(0) NULL DEFAULT NULL COMMENT '0.删除的 1.正常的',
  `wo_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '工单备注',
  `wf_instance_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程实例唯一标识',
  `business_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '业务表单编码',
  `wo_applicant` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '表单申请人，发起人',
  PRIMARY KEY (`wo_code`) USING BTREE,
  INDEX `流程实例唯一标识`(`wf_instance_code`) USING BTREE,
  INDEX `节点唯一标识`(`node_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of work_order
-- ----------------------------
INSERT INTO `work_order` VALUES ('I90cf6044221f11b', 'Ncaf157cf8140e76', 0, NULL, NULL, '2021-06-15 15:14:25', NULL, 1, NULL, 'I752f08a8389dcc5', '123456', NULL);
INSERT INTO `work_order` VALUES ('Ic0ea448d04c39a9', 'Ncaf157cf8140e76', 3, NULL, NULL, '2021-06-15 15:19:11', NULL, 1, NULL, 'I5a55fa649efb172', '123456', NULL);
INSERT INTO `work_order` VALUES ('Ie6f47e9dd03604c', 'Ncaf157cf8140e76', 2, NULL, NULL, '2021-06-15 15:18:13', NULL, 1, NULL, 'I884711581b41dea', '123456', NULL);

-- ----------------------------
-- Table structure for workflow
-- ----------------------------
DROP TABLE IF EXISTS `workflow`;
CREATE TABLE `workflow`  (
  `wf_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程唯一标识',
  `wf_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程名称',
  `wf_createtime` datetime(0) NULL DEFAULT NULL COMMENT '流程创建时间',
  `wf_creator` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `wf_modifytime` datetime(0) NULL DEFAULT NULL COMMENT '流程更新时间',
  `wf_modifier` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '修改人',
  `wf_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `wf_permission` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程权限，逗号分割，用来发起流程：U开头对人，G开头对组织，R开头对角色',
  `wf_flag` int(0) NULL DEFAULT NULL COMMENT '0.删除的 1.正常的',
  `wf_status` int(0) NULL DEFAULT NULL COMMENT '-1.失效的 0.待发布 1.已发布',
  PRIMARY KEY (`wf_code`) USING BTREE,
  INDEX `wf_uuid`(`wf_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of workflow
-- ----------------------------
INSERT INTO `workflow` VALUES ('F006099596ef5a6e', '流程15', '2021-06-18 16:51:47', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('F0eb2c1f2ae24246', '流程2', '2021-06-07 16:49:28', 'admin', NULL, NULL, NULL, NULL, 0, 1);
INSERT INTO `workflow` VALUES ('F119fc9ff7cfab45', '流程12', '2021-06-18 16:51:31', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('F1ceaff17dbbee39', '流程11', '2021-06-17 14:52:51', 'admin', NULL, NULL, NULL, NULL, 0, 1);
INSERT INTO `workflow` VALUES ('F3e80a7905ec51bf', '流程13', '2021-06-18 16:51:39', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('F40ec0bfc62eb2b3', '流程6', '2021-06-17 14:52:18', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('F4756c236597add9', '流程3', '2021-06-07 17:24:21', 'admin', NULL, NULL, NULL, NULL, 0, 1);
INSERT INTO `workflow` VALUES ('F5fc8a3bf24579cb', '流程4', '2021-06-17 14:52:07', 'admin', NULL, NULL, NULL, NULL, 0, 1);
INSERT INTO `workflow` VALUES ('F64cfbc9d9c77199', '流程8', '2021-06-17 14:52:32', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('F7d7079daceb2eab', '流程14', '2021-06-18 16:51:43', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('F7e5afd613f97b9e', '流程测试3', '2021-06-09 16:06:20', 'admin', '2021-06-09 16:16:12', 'admin', NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('F85b3e91d3c0d685', '流程12', '2021-06-17 14:52:55', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('F9605f6855c47801', '流程9', '2021-06-17 14:52:38', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('Fc801614c012b08e', '流程5', '2021-06-17 14:52:12', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('Fe47489a8ee469ba', '流程7', '2021-06-17 14:52:25', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('Ff03955a77cdfdb4', '1', '2021-06-22 20:16:47', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('Ffa6d87d261474e3', '流程10', '2021-06-17 14:52:45', 'admin', NULL, NULL, NULL, NULL, 1, 1);
INSERT INTO `workflow` VALUES ('Z554c9781360e8c5', '流程测试1', '2021-06-02 20:00:34', 'admin', '2021-06-22 20:17:49', 'admin', '123445', '1001,1002', 1, 1);

-- ----------------------------
-- Table structure for workflow_instance
-- ----------------------------
DROP TABLE IF EXISTS `workflow_instance`;
CREATE TABLE `workflow_instance`  (
  `wf_instance_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程实例唯一标识',
  `wf_instance_createtime` datetime(0) NULL DEFAULT NULL COMMENT '流程实例创建时间',
  `wf_instance_updatetime` datetime(0) NULL DEFAULT NULL COMMENT '流程实例更新时间',
  `wf_instance_creator` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程实例发起人',
  `wf_instance_status` int(0) NULL DEFAULT NULL COMMENT '流程实例状态:-1.失效的 0.进行中 1.已结束 2.挂起 3.中断 4.流程失败',
  `wf_instance_remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程实例备注',
  `wf_instance_situation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程实例现状',
  `wf_instance_context` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '流程实例上下文',
  `wf_instance_flag` int(0) NULL DEFAULT NULL COMMENT '0.删除的 1.正常的',
  `wf_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '流程唯一标识',
  PRIMARY KEY (`wf_instance_code`) USING BTREE,
  INDEX `wf_examples_code`(`wf_instance_code`) USING BTREE,
  INDEX `流程唯一标识`(`wf_code`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of workflow_instance
-- ----------------------------
INSERT INTO `workflow_instance` VALUES ('I5a55fa649efb172', '2021-06-15 15:19:11', NULL, 'admin', 0, '测试流程', NULL, NULL, 1, 'Z554c9781360e8c5');
INSERT INTO `workflow_instance` VALUES ('I752f08a8389dcc5', '2021-06-15 15:14:25', NULL, 'admin', 0, '测试流程', NULL, NULL, 1, 'Z554c9781360e8c5');
INSERT INTO `workflow_instance` VALUES ('I884711581b41dea', '2021-06-15 15:18:13', NULL, 'admin', 0, '测试流程', NULL, NULL, 1, 'Z554c9781360e8c5');

SET FOREIGN_KEY_CHECKS = 1;
